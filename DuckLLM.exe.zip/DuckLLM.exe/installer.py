import os
import subprocess
import sys
import time
requirements = r'pip install keyboard requests tqdm'
os.system(requirements)

from tqdm import tqdm



def run_ollama_command(command, description="Installing"):
    print(f"\n--- Starting {description} ---")
    
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    with tqdm(total=100, unit='ticks', dynamic_ncols=True, 
              desc=description, bar_format="{desc}: |{bar}| {elapsed}") as pbar:
        
        while process.poll() is None:
            pbar.update(1) 
            time.sleep(0.1) 
    
    stdout, stderr = process.communicate()

    if process.returncode != 0:
        print(f"\nError during {description}:")
        print(stderr.decode())
        return False
    else:
        print(f"\n{description} completed successfully.")
        return True

def run_setup():
    print("Pulling DuckLLM...")
    pull_command = "ollama pull Qwen2.5:0.5b"
    if not run_ollama_command(pull_command, description="Pulling Ollama Model"):
        sys.exit(1)


    create_command = "ollama create DuckLLM"
    if not run_ollama_command(create_command, description="Creating DuckLLM"):
        sys.exit(1)

    print("\n\n*************************************************")
    print("         Installation Completed! ")
    print("         This Window Will Close Itself In 5 Seconds ")
    print("*************************************************")
    time.sleep(5)

def run_other_function():
    print("Running other utility script functions.")
    

move = r'move "C:\Users\%USERNAME%\Downloads\DuckLLM.exe\DuckLLM.exe\DuckLLM.py" "C:\Users\%USERNAME%\Desktop"'

os.system(move)

run_setup()