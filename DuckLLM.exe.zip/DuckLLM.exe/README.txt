DUCKLLM VERSION "DEV BETA"

For This To Work Ollama Is Required 

Click Shift To Show And Esc To Hide.

To Close It Right Click In The Taskbar And Click End Task