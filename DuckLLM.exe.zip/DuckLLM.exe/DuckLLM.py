print("Now Running Minimize This Command Line And Use Shift To Show And Esc To Hide The AI Input Line")



import tkinter as tk
from tkinter import font as tkfont
import threading
import time
import keyboard 
import requests 
import re 

class AnimatedAIWidget(tk.Tk):
    def __init__(self):
        super().__init__()
        
        # --- 1. Constants & Styling ---
        self.SCREEN_WIDTH = self.winfo_screenwidth()
        self.INITIAL_WIDTH = int(self.SCREEN_WIDTH * 0.65)
        
        self.MIN_HEIGHT = 40  
        self.MATTE_BLACK = "#1a1a1a"
        self.ACCENT_COLOR = "white"
        self.TEXT_COLOR = "white"
        self.ANIMATION_DURATION = 150 
        self.ANIMATION_STEPS = 10     
        self.OLLAMA_URL = "http://localhost:11434/api/generate"
        self.OLLAMA_MODEL = "duckllm:latest"

        # --- 2. Window Setup ---
        self.title("DuckLLM Frontend API")
        self.attributes('-topmost', True)       
        self.overrideredirect(True)             
        self.geometry(f'{self.INITIAL_WIDTH}x{self.MIN_HEIGHT}') 
        self.config(bg=self.MATTE_BLACK)
        
        self.withdraw()
        self.update_idletasks()
        self.deiconify()
        
        self.attributes('-alpha', 0.0) 
        self.is_visible = False
        
        # --- 3. Fonts and Layout ---
        self.text_font = tkfont.Font(family="Arial", size=11)
        self.grid_rowconfigure(1, weight=1) 
        self.grid_columnconfigure(0, weight=1)

        # --- 4. Input Frame ---
        self.input_frame = tk.Frame(self, bg=self.MATTE_BLACK)
        self.input_frame.grid(row=0, column=0, sticky="ew", padx=15, pady=15) 
        self.input_frame.grid_columnconfigure(0, weight=1)
        
        self.input_var = tk.StringVar()
        self.query_entry = tk.Entry(
            self.input_frame, 
            textvariable=self.input_var,
            font=self.text_font,
            bg=self.MATTE_BLACK,
            fg=self.TEXT_COLOR,
            insertbackground=self.ACCENT_COLOR,
            bd=0, 
            highlightthickness=2, 
            highlightbackground=self.ACCENT_COLOR,
            highlightcolor=self.ACCENT_COLOR,
            justify='center'
        )
        self.query_entry.grid(row=0, column=0, sticky="ew")
        self.query_entry.bind("<Return>", self.start_query)

        # --- 5. Response Frame ---
        self.response_frame = tk.Frame(self, bg=self.MATTE_BLACK)
        self.response_frame.grid(row=1, column=0, sticky="nsew", padx=15, pady=(0, 15)) 
        self.response_frame.grid_columnconfigure(0, weight=1)
        self.response_frame.grid_rowconfigure(0, weight=1)
        
        self.response_text = tk.Text(
            self.response_frame,
            wrap='word', 
            font=self.text_font,
            bg=self.MATTE_BLACK,
            fg=self.TEXT_COLOR,
            bd=0,
            relief="flat",
            state='disabled' 
        )
        
        self.response_text.tag_configure("center", justify='center')
        self.response_text.grid(row=0, column=0, sticky="nsew")

        # --- 6. Event Bindings & Key Hook Setup ---
        self.bind("<Escape>", lambda e: self.after(0, self.hide_widget))
        
        threading.Thread(target=self.setup_key_hooks, daemon=True).start()

    def setup_key_hooks(self):
        keyboard.on_press_key('right shift', self.toggle_widget_hook)
        keyboard.wait() 

    def toggle_widget_hook(self, event):
        if self.is_visible:
            self.after(0, self.hide_widget)
        else:
            self.after(0, self.show_widget)

    def show_widget(self):
        if not self.is_visible:
            screen_height = self.winfo_screenheight()
            y_position = int(screen_height * 0.75)
            
            self.geometry(f'+{self.winfo_screenwidth()//2 - self.INITIAL_WIDTH//2}+{y_position}')
            self.animate_in()
            self.after(self.ANIMATION_DURATION, self.query_entry.focus_set)

    def hide_widget(self):
        if self.is_visible:
            self.geometry(f'{self.INITIAL_WIDTH}x{self.MIN_HEIGHT}')
            
            self.input_var.set("")
            
            self.response_text.config(state='normal')
            self.response_text.delete("1.0", "end")
            self.response_text.config(state='disabled')
            
            self.animate_out()
        
    def animate_in(self, step=0):
        if step < self.ANIMATION_STEPS:
            alpha = (step + 1) / self.ANIMATION_STEPS
            self.attributes('-alpha', alpha)
            self.geometry(f'{self.INITIAL_WIDTH}x{self.MIN_HEIGHT}')
            self.after(self.ANIMATION_DURATION // self.ANIMATION_STEPS, self.animate_in, step + 1)
        else:
            self.is_visible = True

    def animate_out(self, step=0):
        if step < self.ANIMATION_STEPS:
            alpha = 1.0 - ((step + 1) / self.ANIMATION_STEPS)
            self.attributes('-alpha', alpha)
            self.after(self.ANIMATION_DURATION // self.ANIMATION_STEPS, self.animate_out, step + 1)
        else:
            self.is_visible = False
            self.attributes('-alpha', 0.0) 
    
    def update_size_with_animation(self, start_height, end_height, step=0):
        if step < self.ANIMATION_STEPS:
            current_height = int(start_height + (end_height - start_height) * (step + 1) / self.ANIMATION_STEPS)
            self.geometry(f'{self.INITIAL_WIDTH}x{current_height}')
            self.after(self.ANIMATION_DURATION // self.ANIMATION_STEPS, 
                       self.update_size_with_animation, 
                       start_height, end_height, step + 1)
        else:
            self.geometry(f'{self.INITIAL_WIDTH}x{end_height}')
            self.query_entry.config(state='normal')
            self.query_entry.focus_set()

    def set_response(self, text):
        self.response_text.config(state='normal')
        self.response_text.delete("1.0", "end")
        
        # 1. Clean up any unwanted formatting markers (like :size=600:)
        cleaned_text = re.sub(r'!:size=\d+:', '', text).strip()
        
        # 2. Insert text and apply the center tag
        self.response_text.insert("1.0", cleaned_text, "center")
        
        self.response_text.config(state='disabled')
        
        temp_label = tk.Label(
            self.response_frame, text=cleaned_text, font=self.text_font, 
            wraplength=self.INITIAL_WIDTH - 30, 
            bg=self.MATTE_BLACK, 
            fg=self.TEXT_COLOR
        )
        temp_label.update_idletasks()
        
        # --- FIX APPLIED HERE: Adjust height calculation for better single-line display ---
        text_height_px = temp_label.winfo_reqheight()
        
        if len(cleaned_text.splitlines()) <= 1 and text_height_px < self.MIN_HEIGHT:
            # Estimate the height of a single line of text plus some margin
            single_line_height = self.text_font.metrics('linespace') + 5
            text_height_px = single_line_height
        
        temp_label.destroy()
        
        # Calculate new total height based on content height and padding 
        new_total_height = self.MIN_HEIGHT + text_height_px + 30 
        
        current_height = self.winfo_height()
        self.update_size_with_animation(current_height, new_total_height)

    def start_query(self, event):
        query = self.input_var.get()
        if not query.strip():
            return

        self.query_entry.config(state='disabled')
        self.set_response("Thinking...")
        threading.Thread(target=self.run_ollama_query, args=(query,), daemon=True).start()

    def run_ollama_query(self, query):
        
        def handle_ollama_request(q):
            
            headers = {'Content-Type': 'application/json'}
            data = {
                'model': self.OLLAMA_MODEL, 
                'prompt': q,
                'stream': False
            }
            
            try:
                response = requests.post(self.OLLAMA_URL, headers=headers, json=data, timeout=30)
                response.raise_for_status()
                
                return response.json().get('response', 'ERROR: Ollama response field missing.')
                
            except requests.exceptions.RequestException as e:
                return f"ERROR: Could not connect to Ollama. Ensure Ollama is running and the model ({self.OLLAMA_MODEL}) is pulled. Details: {e}"
            except Exception as e:
                return f"UNEXPECTED ERROR: {type(e).__name__}: {e}"
            
        try:
            response = handle_ollama_request(query)
            self.after(0, self.set_response, response)
            
        except Exception as e:
            error_msg = f"Unexpected error during query processing: {e}"
            self.after(0, self.set_response, error_msg)

if __name__ == "__main__":
    app = AnimatedAIWidget()
    app.mainloop()