import os
import subprocess
import sys
import time



def run_ollama_command(command, description="Installing"):
    print(f"\n--- Starting {description} ---")
    
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    

        

    stdout, stderr = process.communicate()

    if process.returncode != 0:
        print(f"\nError during {description}:")
        print(stderr.decode())
        return False
    else:
        print(f"\n{description} completed successfully.")
        return True

def run_setup():
    print("Pulling DuckLLM...")
    pull_command = "ollama pull Qwen2.5:0.5b"
    if not run_ollama_command(pull_command, description="Pulling Ollama Model"):
        sys.exit(1)


    create_command = "ollama create DuckLLM"
    if not run_ollama_command(create_command, description="Creating DuckLLM"):
        sys.exit(1)

    print("\n\n*************************************************")
    print("         Installation Completed! ")
    print("         This Window Will Close Itself In 5 Seconds ")
    print("*************************************************")
    time.sleep(5)

def run_other_function():
    print("Running other utility script functions.")
    

requirements = r'pip install keyboard --break-system-packages' #Safe And Tested If You Encounter Issues Please Inform (Discord : duck_ae)
move = r'mv "~/Downloads/DuckLLM_Linux" "~/"'


os.system(requirements)
os.system(move)

run_setup()
